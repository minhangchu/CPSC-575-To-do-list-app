//
//  ContentView.swift
//  Make It So SL Live
//
//  Created by Minh Hang Chu on 9/21/20.
//  Copyright © 2020 Minh Hang Chu. All rights reserved.
//

import SwiftUI

struct TaskListView: View {
    var body: some View {
        Text("Implement the UI")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        TaskListView()
    }
}
